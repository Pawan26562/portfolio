import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dumbbell, Salad, ChevronDown } from 'lucide-react';
import { exercises, meals } from './data';
import { ExerciseCard } from './components/ExerciseCard';
import { MealCard } from './components/MealCard';

function App() {
  const [level, setLevel] = useState('beginner');
  const [goal, setGoal] = useState('muscular');
  const [activeSection, setActiveSection] = useState('both');

  const filteredExercises = exercises.filter(
    exercise => exercise.level === level && exercise.goal === goal
  );

  const filteredMeals = meals.filter(
    meal => meal.goal === goal
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-blue-600 text-white py-8 sticky top-0 z-10 shadow-lg"
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <motion.h1 
              className="text-3xl font-bold flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
            >
              <Dumbbell size={32} />
              FitLife Pro
            </motion.h1>
            <div className="flex gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => setActiveSection(activeSection === 'exercises' ? 'both' : 'exercises')}
                className={`px-4 py-2 rounded-full ${
                  activeSection === 'exercises' || activeSection === 'both'
                    ? 'bg-white text-blue-600'
                    : 'bg-blue-700 text-white'
                }`}
              >
                Exercises
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => setActiveSection(activeSection === 'meals' ? 'both' : 'meals')}
                className={`px-4 py-2 rounded-full ${
                  activeSection === 'meals' || activeSection === 'both'
                    ? 'bg-white text-blue-600'
                    : 'bg-blue-700 text-white'
                }`}
              >
                Meals
              </motion.button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-md p-6 mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                Experience Level
                <ChevronDown size={20} className="text-gray-400" />
              </h2>
              <div className="flex gap-4">
                {['beginner', 'intermediate', 'advanced'].map((l) => (
                  <motion.button
                    key={l}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setLevel(l)}
                    className={`px-4 py-2 rounded-full transition-all duration-300 ${
                      level === l
                        ? 'bg-blue-600 text-white shadow-lg'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {l.charAt(0).toUpperCase() + l.slice(1)}
                  </motion.button>
                ))}
              </div>
            </div>
            <div>
              <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                Fitness Goal
                <ChevronDown size={20} className="text-gray-400" />
              </h2>
              <div className="flex gap-4">
                {['muscular', 'lean', 'fat-loss'].map((g) => (
                  <motion.button
                    key={g}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setGoal(g)}
                    className={`px-4 py-2 rounded-full transition-all duration-300 ${
                      goal === g
                        ? 'bg-blue-600 text-white shadow-lg'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {g.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Exercises Section */}
          {(activeSection === 'exercises' || activeSection === 'both') && (
            <motion.section 
              key="exercises"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-12"
            >
              <div className="flex items-center gap-2 mb-6">
                <Dumbbell className="text-blue-600" />
                <h2 className="text-2xl font-bold">Recommended Exercises</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredExercises.map((exercise, index) => (
                  <ExerciseCard key={exercise.name} exercise={exercise} index={index} />
                ))}
              </div>
            </motion.section>
          )}

          {/* Meals Section */}
          {(activeSection === 'meals' || activeSection === 'both') && (
            <motion.section
              key="meals"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <Salad className="text-green-600" />
                <h2 className="text-2xl font-bold">Meal Recommendations</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredMeals.map((meal, index) => (
                  <MealCard key={meal.name} meal={meal} index={index} />
                ))}
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
} export default App;