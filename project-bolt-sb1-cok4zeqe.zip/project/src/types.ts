export type ExperienceLevel = 'beginner' | 'intermediate' | 'advanced';
export type Goal = 'muscular' | 'lean' | 'fat-loss';

export interface Exercise {
  name: string;
  description: string;
  sets: number;
  reps: string;
  imageUrl: string;
  level: ExperienceLevel;
  goal: Goal;
  steps: string[];
  videoUrl: string;
  duration: string;
  equipment: string[];
  targetMuscles: string[];
}

export interface Meal {
  name: string;
  description: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  imageUrl: string;
  goal: Goal;
  ingredients: string[];
  instructions: string[];
  prepTime: string;
  cookTime: string;
  servings: number;
  videoUrl: string;
}