import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Modal } from './Modal';
import { PlayCircle } from 'lucide-react';

export const ExerciseCard = ({ exercise, index }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        whileHover={{ scale: 1.02 }}
        onClick={() => setIsModalOpen(true)}
        className="bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl cursor-pointer"
      >
        <div className="relative">
          <img 
            src={exercise.imageUrl} 
            alt={exercise.name}
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-2 right-2 bg-blue-600 text-white px-3 py-1 rounded-full text-sm">
            {exercise.level}
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-3">{exercise.name}</h3>
          <p className="text-gray-600 mb-4">{exercise.description}</p>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-3 rounded-lg text-center">
              <span className="block text-gray-500 text-sm">Sets</span>
              <span className="text-blue-600 font-semibold">{exercise.sets}</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg text-center">
              <span className="block text-gray-500 text-sm">Reps</span>
              <span className="text-blue-600 font-semibold">{exercise.reps}</span>
            </div>
          </div>
        </div>
      </motion.div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <h2 className="text-3xl font-bold">{exercise.name}</h2>
            <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm">
              {exercise.level}
            </span>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <img 
                src={exercise.imageUrl} 
                alt={exercise.name}
                className="w-full rounded-lg mb-6"
              />
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Duration</h4>
                  <p>{exercise.duration}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Sets & Reps</h4>
                  <p>{exercise.sets} sets × {exercise.reps}</p>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <h4 className="font-semibold mb-2">Equipment Needed</h4>
                <ul className="list-disc list-inside">
                  {exercise.equipment.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Target Muscles</h4>
                <div className="flex flex-wrap gap-2">
                  {exercise.targetMuscles.map((muscle, index) => (
                    <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      {muscle}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4">Instructions</h3>
                <ol className="space-y-4">
                  {exercise.steps.map((step, index) => (
                    <li key={index} className="flex gap-4">
                      <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center">
                        {index + 1}
                      </span>
                      <p className="text-gray-700">{step}</p>
                    </li>
                  ))}
                </ol>
              </div>

              <a
                href={exercise.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors"
              >
                <PlayCircle size={24} />
                Watch Tutorial Video
              </a>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};