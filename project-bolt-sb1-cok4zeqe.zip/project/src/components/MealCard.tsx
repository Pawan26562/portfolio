import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Meal } from '../types';
import { Modal } from './Modal';
import { PlayCircle, Clock } from 'lucide-react';

interface MealCardProps {
  meal: Meal;
  index: number;
}

export const MealCard: React.FC<MealCardProps> = ({ meal, index }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        whileHover={{ scale: 1.02 }}
        onClick={() => setIsModalOpen(true)}
        className="bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl cursor-pointer"
      >
        <div className="relative">
          <img 
            src={meal.imageUrl} 
            alt={meal.name}
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-2 right-2 bg-green-600 text-white px-3 py-1 rounded-full text-sm">
            {meal.goal}
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-3">{meal.name}</h3>
          <p className="text-gray-600 mb-4">{meal.description}</p>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-center">
                <span className="block text-gray-500 text-sm">Calories</span>
                <span className="text-green-600 font-semibold">{meal.calories}</span>
              </div>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-center">
                <span className="block text-gray-500 text-sm">Protein</span>
                <span className="text-green-600 font-semibold">{meal.protein}g</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <h2 className="text-3xl font-bold">{meal.name}</h2>
            <span className="bg-green-600 text-white px-4 py-1 rounded-full text-sm">
              {meal.goal}
            </span>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <img 
                src={meal.imageUrl} 
                alt={meal.name}
                className="w-full rounded-lg mb-6"
              />
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                  <Clock className="text-green-600" />
                  <div>
                    <h4 className="font-semibold">Prep Time</h4>
                    <p className="text-gray-600">{meal.prepTime}</p>
                  </div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                  <Clock className="text-green-600" />
                  <div>
                    <h4 className="font-semibold">Cook Time</h4>
                    <p className="text-gray-600">{meal.cookTime}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Calories</h4>
                  <p className="text-2xl text-green-600">{meal.calories}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Servings</h4>
                  <p className="text-2xl text-green-600">{meal.servings}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <h4 className="font-semibold mb-1">Protein</h4>
                  <p className="text-xl text-green-600">{meal.protein}g</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <h4 className="font-semibold mb-1">Carbs</h4>
                  <p className="text-xl text-green-600">{meal.carbs}g</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <h4 className="font-semibold mb-1">Fats</h4>
                  <p className="text-xl text-green-600">{meal.fats}g</p>
                </div>
              </div>
            </div>

            <div>
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4">Ingredients</h3>
                <ul className="space-y-2">
                  {meal.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                      {ingredient}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-4">Instructions</h3>
                <ol className="space-y-4">
                  {meal.instructions.map((instruction, index) => (
                    <li key={index} className="flex gap-4">
                      <span className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center">
                        {index + 1}
                      </span>
                      <p className="text-gray-700">{instruction}</p>
                    </li>
                  ))}
                </ol>
              </div>

              <a
                href={meal.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors"
              >
                <PlayCircle size={24} />
                Watch Recipe Video
              </a>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};