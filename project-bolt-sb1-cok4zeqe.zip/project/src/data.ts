import { Exercise, Meal } from './types';

export const exercises: Exercise[] = [
  {
    name: 'Push-ups',
    description: 'Basic chest and triceps exercise',
    sets: 3,
    reps: '10-12',
    imageUrl: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800',
    level: 'beginner',
    goal: 'muscular',
    steps: [
      'Start in a plank position with hands slightly wider than shoulders',
      'Keep your body in a straight line from head to heels',
      'Lower your body until your chest nearly touches the ground',
      'Push back up to the starting position',
      'Keep your core tight throughout the movement'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=IODxDxX7oi4',
    duration: '10-15 minutes',
    equipment: ['None required'],
    targetMuscles: ['Chest', 'Triceps', 'Shoulders', 'Core']
  },
  {
    name: 'Pull-ups',
    description: 'Advanced back and biceps exercise',
    sets: 4,
    reps: '8-10',
    imageUrl: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=800',
    level: 'advanced',
    goal: 'muscular',
    steps: [
      'Grip the pull-up bar with hands slightly wider than shoulders',
      'Hang with arms fully extended',
      'Pull yourself up until your chin is over the bar',
      'Lower yourself back down with control',
      'Maintain proper form throughout'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=eGo4IYlbE5g',
    duration: '15-20 minutes',
    equipment: ['Pull-up bar'],
    targetMuscles: ['Back', 'Biceps', 'Forearms', 'Core']
  },
  {
    name: 'Squats',
    description: 'Compound leg exercise',
    sets: 3,
    reps: '12-15',
    imageUrl: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=800',
    level: 'intermediate',
    goal: 'muscular',
    steps: [
      'Stand with feet shoulder-width apart',
      'Keep your chest up and core engaged',
      'Lower your body as if sitting back into a chair',
      'Keep knees in line with toes',
      'Push through your heels to return to standing'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=ultWZbUMPL8',
    duration: '20-25 minutes',
    equipment: ['Optional: Dumbbells or Barbell'],
    targetMuscles: ['Quadriceps', 'Hamstrings', 'Glutes', 'Core']
  },
  {
    name: 'HIIT Sprints',
    description: 'High-intensity cardio',
    sets: 5,
    reps: '30 sec',
    imageUrl: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=800',
    level: 'intermediate',
    goal: 'fat-loss',
    steps: [
      'Warm up with light jogging for 5 minutes',
      'Sprint at maximum effort for 30 seconds',
      'Walk or jog slowly for 60 seconds to recover',
      'Repeat for desired number of sets',
      'Cool down with light jogging and stretching'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=QgXJb_T5sU4',
    duration: '20-30 minutes',
    equipment: ['Running space or Treadmill'],
    targetMuscles: ['Full body', 'Cardiovascular system']
  },
];

export const meals: Meal[] = [
  {
    name: 'Protein-Packed Breakfast Bowl',
    description: 'Oatmeal with protein powder, banana, and almonds',
    calories: 450,
    protein: 30,
    carbs: 45,
    fats: 15,
    imageUrl: 'https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=800',
    goal: 'muscular',
    ingredients: [
      '1 cup rolled oats',
      '1 scoop vanilla protein powder',
      '1 banana, sliced',
      '1/4 cup almonds, chopped',
      '1 tbsp honey',
      '1 cup almond milk'
    ],
    instructions: [
      'Cook oats with almond milk according to package instructions',
      'Let cool slightly and stir in protein powder',
      'Top with sliced banana and chopped almonds',
      'Drizzle with honey',
      'Add more almond milk if desired'
    ],
    prepTime: '5 minutes',
    cookTime: '5 minutes',
    servings: 1,
    videoUrl: 'https://www.youtube.com/watch?v=kNJKx4XCQ3Y'
  },
  {
    name: 'Lean Chicken Salad',
    description: 'Grilled chicken breast with mixed greens and light dressing',
    calories: 350,
    protein: 40,
    carbs: 10,
    fats: 12,
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800',
    goal: 'lean',
    ingredients: [
      '6 oz grilled chicken breast',
      '3 cups mixed greens',
      '1/2 cup cherry tomatoes',
      '1/4 cucumber, sliced',
      '2 tbsp light balsamic dressing',
      '1/4 avocado'
    ],
    instructions: [
      'Season and grill chicken breast until cooked through',
      'Wash and prepare vegetables',
      'Slice chicken breast',
      'Combine all ingredients in a large bowl',
      'Drizzle with dressing and toss gently'
    ],
    prepTime: '10 minutes',
    cookTime: '15 minutes',
    servings: 1,
    videoUrl: 'https://www.youtube.com/watch?v=qB2UgwNrNLk'
  },
  {
    name: 'Fat-Loss Power Bowl',
    description: 'Quinoa, vegetables, and lean protein',
    calories: 400,
    protein: 35,
    carbs: 35,
    fats: 10,
    imageUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800',
    goal: 'fat-loss',
    ingredients: [
      '1 cup cooked quinoa',
      '4 oz grilled tofu or chicken',
      '1 cup roasted broccoli',
      '1 cup roasted sweet potato',
      '1 tbsp olive oil',
      'Herbs and spices to taste'
    ],
    instructions: [
      'Cook quinoa according to package instructions',
      'Roast vegetables with olive oil and seasonings',
      'Prepare protein of choice',
      'Combine all ingredients in a bowl',
      'Add additional seasonings to taste'
    ],
    prepTime: '15 minutes',
    cookTime: '25 minutes',
    servings: 1,
    videoUrl: 'https://www.youtube.com/watch?v=7W8n8NS1jGM'
  },
];